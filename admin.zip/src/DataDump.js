
import firebase from 'firebase';
import 'firebase/auth';
import 'firebase/database';
import 'firebase/firebase-firestore'
var config = {
  apiKey: "AIzaSyALUrUT8h6_oBFaOOMmmbPM0UVyMB7OEx4",
  authDomain: "makeit-4ee8e.firebaseapp.com",
  databaseURL: "https://makeit-4ee8e-default-rtdb.firebaseio.com",
  projectId: "makeit-4ee8e",
  storageBucket: "makeit-4ee8e.appspot.com",
  messagingSenderId: "293032715387",
  appId: "1:293032715387:web:07ba5b8a64cc7edd622ede",
  measurementId: "G-D815G8S98N"
};

firebase.initializeApp(config);

var db = firebase.database();
var fs = firebase.firestore();
var auth = firebase.auth();

export {db,fs,auth}


